from flask import Flask, render_template, request, jsonify, make_response
import requests
import json
from werkzeug.exceptions import NotFound
import argparse

app = Flask(__name__)

PORT = 3203
HOST = '0.0.0.0'

with open('{}/databases/users.json'.format("."), "r") as jsf:
   users = json.load(jsf)["users"]

@app.route("/", methods=['GET'])
def home():
   return "<h1 style='color:blue'>Welcome to the User service!</h1>"

@app.route("/users", methods=['GET'])
def get_users():
   res = make_response(jsonify(users), 200)
   return res

@app.route("/users/<username>",methods=['GET'])
def get_user_byname(username):
   for user in users:
      if str(user["id"]) == str(username):
         res = make_response(jsonify(user), 200)
         return res

   res = make_response(jsonify({"error":"userid not found"}),400)
   return res

@app.route("/showtimes", methods=['GET'])
def acces_showtimes():
   res = []
   try:
      req = "http://localhost:3202/showtimes"
      response = requests.get(req)
      res.append(response.json())
      return make_response(jsonify(res))
   except:
      return make_response(jsonify({"error":"fail to join the Showtimes service"}),400)
   

@app.route("/bookings", methods=['GET'])
def acces_bookings():
   res = []
   try:
      req = "http://localhost:3201/bookings"
      response = requests.get(req)
      res.append(response.json())
      return make_response(jsonify(res))
   except:
      return make_response(jsonify({"error":"fail to join the Bookings service"}),400)   


@app.route("/movies", methods=['GET'])
def acces_movies():
   res = []
   try:
      req = "http://localhost:3200/json"
      response = requests.get(req)
      res.append(response.json())
      return make_response(jsonify(res))
   except:
      return make_response(jsonify({"error":"fail to join the Movie service"}),400)   


# @app.route("/users/bookings/<username>",methods=['GET'])
# def get_user_bookings_byname(username):
#    for user in users:
#       if str(user["name"]) == str(username):
#          rid = user["id"]
#          try:
#             req = "http://booking:3201/bookings/{}".format(rid)
#             response = requests.get(req)
#             listbookings = response.json()
#             return make_response(jsonify(listbookings))
#          except:
#             return make_response(jsonify({"error":"fail to join the Booking service"}),400)
#    res = make_response(jsonify({"error":"username not found"}),400)
#    return res


# @app.route("/users/movies/<username>",methods=['GET'])
# def get_user_movies_byname(username):
#    res = []
#    for user in users:
#       if str(user["name"]) == str(username):
#          rid = user["id"]
#          try:
#             req = "http://booking:3201/bookings/{}".format(rid)
#             response = requests.get(req)
#             listbookings = response.json()
#             for date in listbookings["dates"]:
#                for movieid in date["movies"]:
#                   try:
#                      #print("http://movie:3200/movies/{}".format(movieid))
#                      response = requests.get("http://movie:3200/movies/{}".format(movieid))
#                      res.append(response.json())
#                   except:
#                      return make_response(jsonify({"error":"fail to join the Movie service"}),400)
#             return make_response(jsonify(res))
#          except:
#             return make_response(jsonify({"error":"fail to join the Booking service"}),400)
#    res = make_response(jsonify({"error":"username not found"}),400)
#    return res


if __name__ == "__main__":
   print("Server running in port %s"%(PORT))
   app.run(host=HOST, port=PORT)