from flask import Flask, render_template, request, jsonify, make_response
import requests
import json
from werkzeug.exceptions import NotFound

app = Flask(__name__)

PORT = 3201
HOST = '0.0.0.0'

with open('{}/databases/bookings.json'.format("."), "r") as jsf:
   bookings = json.load(jsf)["bookings"]

@app.route("/", methods=['GET'])
def home():
   return "<h1 style='color:blue'>Welcome to the Booking service!</h1>"

@app.route("/bookings", methods=['GET'])
def get_booking_list():
   res = make_response(jsonify(bookings), 200)
   return res            

@app.route("/bookings/<userid>", methods=['GET'])
def get_booking_for_user(userid):
   for user in bookings:
      if str(user["userid"]) == str(userid):
         res = make_response(jsonify(user), 200)
         return res

   res = make_response(jsonify({"error":"username not found"}),400)
   return res

@app.route("/bookings/<userid>", methods=['POST'])
def add_booking_byuser(userid):
   # get date and movie from the body of the request
   req = request.get_json()
   rmovie = req["movieid"]
   rdate = req["date"]
   print(rdate)

   # request to the Showtime service the list of movies at rdate
   try:
      response = requests.get("http://showtime:3202/showmovies/{}".format(rdate))
      listmovies = response.json()
   except:
      return make_response(jsonify({"error":"fail to join the Showtime service"}),400)

   # check compatibility of the demand
   if str(rmovie) in listmovies:
      # find the good entry in the database
      for item in bookings:
         if str(item["userid"]) == str(userid):
            # search if the date already exists
            for dateitem in item["dates"]:
               if str(dateitem["date"]) == str(rdate):
                  dateitem["movies"].append(rmovie)
                  return make_response(jsonify(item))
            # if date not found, new entry
            res={}
            res["date"] = rdate
            res["movies"] = [rmovie]
            item["dates"].append(res)
            return make_response(jsonify(res))
   return make_response(jsonify({"error": "request not available in the schedule"}))

if __name__ == "__main__":
   print("Server running in port %s"%(PORT))
   app.run(host=HOST, port=PORT)