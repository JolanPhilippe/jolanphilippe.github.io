package v1;

import java.util.Comparator;

public class ComparateurMulti <T, C1 extends Comparator<T>, C2 extends Comparator<T>> implements Comparator<T> {

    Comparator<T> c1;
    Comparator<T> c2;

    public ComparateurMulti(C1 c1, C2 c2) {
        super();
        this.c1 = c1;
        this.c2 = c2;
    }

    @Override
    public int compare(T o1, T o2) {
        int comparison = c1.compare(o1, o2);
        if (comparison != 0) {
            return comparison;
        } else {
            return c2.compare(o1, o2);
        }
    }

}
