package v1;

public class Bus implements IVehicule {

    private int longueur;
    private int passagers;
    private String immatriculation;

    public Bus(int longueur, int passagers, String immatriculation){
        this.longueur = longueur;
        this.passagers = passagers;
        this.immatriculation = immatriculation;
    }

    @Override
    public int getLongueur() {
        return this.longueur;
    }

    @Override
    public int getPassagers() {
        return this.passagers;
    }

    @Override
    public String getImmatriculation() {
        return this.immatriculation;
    }

    @Override
    public float calculerTarif() {
        float base = 200 + 50 * this.longueur;
        return base + getPassagers() * IVehicule.TARIF_PERSONNE;
    }

    public String toString(){
        StringBuilder sb = new StringBuilder("Bus      ");
        sb.append("[" + immatriculation + "]");
        sb.append("(" + String.format("%02d",passagers) + " passagers; ");
        sb.append(longueur + " mètres)");
        return sb.toString();
    }

    public IVehicule clone(){
      return new Bus(this.longueur, this.passagers, new String(this.immatriculation));
    }

    @Override
    public int compareTo(IVehicule arg0) {
        return Integer.compare(this.longueur , arg0.getLongueur());
    } 
    
}
