package v1;

public class Ambulance extends Auto{

    public Ambulance(int passagers, String immatriculation, boolean tout_terrain) {
        super(passagers, immatriculation, tout_terrain);
    }

    @Override
    public float calculerTarif(){
        return getPassagers() * IVehicule.TARIF_PERSONNE;
    }

    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder("Ambulance");
        sb.append("[" + this.getImmatriculation() + "]");
        sb.append("(" + String.format("%02d",this.getPassagers()) + " passagers; ");
        sb.append(this.getLongueur() + " mètres)");
        if (this.tout_terrain){
            sb.append(" -- TOUT TERRAIN");
        }
        return sb.toString();
    }
}
