package v1;

public interface Cloneable<T> {
    public T clone();
}
