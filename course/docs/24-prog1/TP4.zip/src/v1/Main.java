package v1;

import java.util.Random;

public class Main {
    
    private static Random random = new Random();

    private static String makeRandomImmatriculation(){
        // format : aa####aa
        StringBuilder sb = new StringBuilder();
        sb.append((char)(random.nextInt(26) + 'A'));
        sb.append((char)(random.nextInt(26) + 'A'));
        sb.append(String.format("%04d", random.nextInt(9999)));
        sb.append((char)(random.nextInt(26) + 'A'));
        sb.append((char)(random.nextInt(26) + 'A'));
        return sb.toString();
    }

    private static IVehicule makeRandomVehicule(){
        IVehicule nv;
        String immatriculation = makeRandomImmatriculation();
        switch (random.nextInt(4)) {
            case 0:
                nv = new Auto(random.nextInt(1,8), immatriculation, random.nextBoolean());
                break;
            case 1:
                nv = new Bus(random.nextInt(1,6), random.nextInt(1,55), immatriculation);
                break;
            case 2:
                nv = new Ambulance(random.nextInt(1,6), immatriculation, random.nextBoolean());
                break;
            case 3:
                nv = new Cycle(random.nextInt(1,3), immatriculation, random.nextBoolean());
                break;
            default:
                nv = null;
                break;
        }
        return nv;
    }

    public static void main(String[] args) {
        // 1 - Creer un Ferry
        // 2 - Repeter les operations ci dessous jusqu'à ce que le ferry soit plein
        //      - créer différentes sortes de véhicules ;
        //      - ajouter chacun d’eux dans le ferry ;  
        //      - afficher le contenu détaillé du ferry.
        Ferry costaDiadema = new Ferry(300, 6300);
        IVehicule vehicule;
        do {
            vehicule = makeRandomVehicule();
        } while(costaDiadema.ajouter(vehicule));
        ComparateurTarif ct = new ComparateurTarif();
        ComparateurLongueur cl = new ComparateurLongueur();
        ComparateurMulti<IVehicule, ComparateurLongueur, ComparateurTarif> cm =
                new ComparateurMulti<>(cl, ct);
        costaDiadema.trier(cm);
        System.out.println(costaDiadema);
    }

}
