package v1;

public class Cycle implements IVehicule{

    private int longueur;
    private int passagers;
    private String immatriculation;
    private boolean tout_terrain;

    public Cycle(int longueur, String immatriculation, boolean tout_terrain){
        this.longueur = longueur;
        this.passagers = 1;
        this.tout_terrain = tout_terrain;
        this.immatriculation = immatriculation;
    }

    @Override
    public int getLongueur() {
        return this.longueur;
    }

    @Override
    public int getPassagers() {
        return this.passagers;
    }

    @Override
    public String getImmatriculation() {
        return this.immatriculation;
    }

    @Override
    public float calculerTarif() {
        float base = 20;
        return base + getPassagers() * IVehicule.TARIF_PERSONNE;
    }

    public String toString(){
        StringBuilder sb = new StringBuilder("Cycle    ");
        sb.append("[" + immatriculation + "]");
        sb.append("(" + String.format("%02d",passagers) + " passager; ");
        sb.append(longueur + " mètres)");
        if (tout_terrain){
            sb.append(" -- TOUT TERRAIN");
        }
        return sb.toString();
    }

    public IVehicule clone(){
        return new Cycle(this.longueur, new String(this.immatriculation), this.tout_terrain);
    }

    @Override
    public int compareTo(IVehicule arg0) {
        return Integer.compare(this.longueur , arg0.getLongueur());
    }

}
