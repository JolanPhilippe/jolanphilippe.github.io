package v1;

import java.util.Comparator;

public class ComparateurTarif implements Comparator<IVehicule> {
    private boolean reverse;

    public ComparateurTarif(){
        super();
        this.reverse = false;
    }

    public ComparateurTarif(boolean reverse){
        super();
        this.reverse = reverse;
    }

    @Override
    public int compare(IVehicule o1, IVehicule o2) {
        if (this.reverse){
            return Float.compare(o2.calculerTarif(), o1.calculerTarif());
        }else{
            return Float.compare(o1.calculerTarif(), o2.calculerTarif());
        }
    }
}
