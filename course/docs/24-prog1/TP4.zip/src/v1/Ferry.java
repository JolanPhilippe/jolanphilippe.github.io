package v1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Un ferry transporte des véhicules
 */
public class Ferry
{

  private int capaLongueur;
  private int capaPassagers;
  private int longueur;
  private int passagers;
  private List<IVehicule> vehicules;

  public Ferry (int capaLongueur, int capaPassagers )
  {
    this.capaLongueur = capaLongueur;
    this.capaPassagers = capaPassagers;
    this.longueur = 0;
    this.passagers = 0;
    this.vehicules = new ArrayList<>();
  }

  // accesseurs
  public int getCapaLongueur()  { return this.capaLongueur; }
  public int getCapaPassagers() { return this.capaPassagers; }
  public int getLongueur()	{ return this.longueur; }
  public int getPassagers()	{ return this.passagers; }

  /** ajouter un véhicule dans le ferry.
      sans effet s'il n'y a plus de place
      @param v : véhicule à ajouter
      @return vrai si l'ajout a eu lieu, faux sinon
  */
  public boolean ajouter(IVehicule v)
  {
    if (! (v.getLongueur() + this.longueur < this.capaLongueur))
      return false;
    if (! (v.getPassagers() + this.passagers < this.capaPassagers))
      return false;
    this.longueur += v.getLongueur();
    this.passagers += v.getPassagers();
    return this.vehicules.add(v);
  }

  // calculer le tarif de l'ensemble des véhicules présents dans le ferry
  public float calculerTarif()
  {
    float tarif = 0.0f;
    for (IVehicule v : this.vehicules){
      tarif += v.calculerTarif();
    }
    return tarif;
  }

  // représentation affichable du ferry
  public String toString()
  {
    StringBuilder sb = new StringBuilder();
    for (IVehicule v : this.vehicules){
      sb.append(v.toString());
      sb.append("\n");
    }
    return sb.toString();
  }

  public void trier() {
    Collections.sort(this.vehicules);
  }

  public void trier(Comparator<IVehicule> comparator) {
    Collections.sort(this.vehicules, comparator);
  }

}
