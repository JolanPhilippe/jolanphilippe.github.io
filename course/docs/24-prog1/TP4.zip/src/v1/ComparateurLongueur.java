package v1;

import java.util.Comparator;

public class ComparateurLongueur implements Comparator<IVehicule> {
    private boolean reverse;

    public ComparateurLongueur(){
        super();
        this.reverse = false;
    }

    public ComparateurLongueur(boolean reverse){
        super();
        this.reverse = true;
    }

    @Override
    public int compare(IVehicule o1, IVehicule o2) {
        if (this.reverse){
            return Float.compare(o2.getLongueur(), o1.getLongueur());
        }else{
            return Float.compare(o1.getLongueur(), o2.getLongueur());
        }
    }
}
