package fr.info.orleans.pnt.springmvc.tpspringmvcevenements.modele;

public class UtilisateurInconnuException extends Throwable {
    public UtilisateurInconnuException(String s) {
        super(s);
    }
}
