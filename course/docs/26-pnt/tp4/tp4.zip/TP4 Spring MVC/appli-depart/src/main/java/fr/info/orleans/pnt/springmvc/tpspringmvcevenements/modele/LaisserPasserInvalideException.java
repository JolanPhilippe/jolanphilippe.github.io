package fr.info.orleans.pnt.springmvc.tpspringmvcevenements.modele;

public class LaisserPasserInvalideException extends Exception {
}
