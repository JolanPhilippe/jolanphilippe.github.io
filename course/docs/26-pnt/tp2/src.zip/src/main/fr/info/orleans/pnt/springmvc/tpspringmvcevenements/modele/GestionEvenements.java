package fr.info.orleans.pnt.springmvc.tpspringmvcevenements.modele;

import fr.info.orleans.pnt.springmvc.tpspringmvcevenements.Evenement;
import fr.info.orleans.pnt.springmvc.tpspringmvcevenements.dto.EvenementDTO;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/* Facade métier
*
* @Component:
* - GPT:
*   L’annotation @Component en Spring sert à marquer une classe comme un composant Spring, c’est-à-dire une
*   classe que Spring doit détecter, instancier et gérer automatiquement au moment du démarrage de l’application.
* - Enseignant:
*   Composant du modèle que Spring detecte, et peut être injecté ailleurs
* */


@Component
public class GestionEvenements {

    private List<Evenement> evenements = new ArrayList<>();
    private int compteur = 0;

    public int enregistrer(String nom, String lieu, String date){
        Evenement e = new Evenement(compteur, nom, lieu, date);
        compteur++;
        evenements.add(e);
        return e.getIdentifiant();
    }

    public int enregistrer(EvenementDTO e) {
        Evenement evenement = new Evenement(compteur, e.getNom(), e.getLieu(),
                e.getDate());
        compteur++;
        // e.setIdentifiant(evenement.getIdentifiant());
        evenements.add(evenement);
        return evenement.getIdentifiant();
    }

    public Evenement trouverParId(int id) throws EvenementInconnuException {
        return evenements.stream()
                .filter(e -> e.getIdentifiant() == id)
                .findFirst()
                .orElseThrow(() -> new EvenementInconnuException("Événement inconnu :" + id));
    }

    public List<Evenement> lister() {
        return evenements;
    }
}
