package fr.info.orleans.pnt.springmvc.tpspringmvcevenements.controleur;

import fr.info.orleans.pnt.springmvc.tpspringmvcevenements.Evenement;
import fr.info.orleans.pnt.springmvc.tpspringmvcevenements.dto.EvenementDTO;
import fr.info.orleans.pnt.springmvc.tpspringmvcevenements.modele.EvenementInconnuException;
import fr.info.orleans.pnt.springmvc.tpspringmvcevenements.modele.GestionEvenements;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;

/* Spring va scanner les classes, et instancier automatiquement
les classes @Controller; @Service; etc. */
@Controller
@RequestMapping("/mesevenements")
public class EvenementControleur {

    private final GestionEvenements gestion;

    public EvenementControleur(GestionEvenements gestion) {
        this.gestion = gestion;
    }

    @PostMapping("/creation")
    public String ajouterViaModel(
            /* @ModelAttribute encapsule les @RequestParam de `ajouter`
             * Du coup, l'objet créé est rempli automatiquement avec les champs de la requête
             * Exemple:
             * http://localhost:8080/mesevenements/ajouter2?nom=Festival&lieu=Marseille&date=2025-08-01
             *  */
            @Valid @ModelAttribute("evenement") EvenementDTO evenement,
            BindingResult result,
            Model model
    ){
        if (result.hasErrors()){
            return "creation";
        }
        int identifiant = gestion.enregistrer(evenement);
        model.addAttribute("message", "Événement ajouté avec succès !");
        model.addAttribute("identifiant", identifiant);
        return "resume";
    }

//    @PostMapping("/creation")
//    public String ajouter(
//            @RequestParam String nom,
//            @RequestParam String lieu,
//            @RequestParam String date,
//            Model model
//    ){
//        int identifiant = gestion.enregistrer(nom, lieu, date);
//        model.addAttribute("message", "Événement ajouté avec succès !");
//        model.addAttribute("identifiant", identifiant);
//        return "resume";
//    }

    @GetMapping("/creationForm")
    public String gotoCreationForm(Model model) {
        model.addAttribute("evenement", new EvenementDTO());
        return "creation";
    }

//    @GetMapping("/creationForm")
//    public String gotoCreation(){
//        return "creation";
//    }

    @GetMapping("/evenement/{id}")
    public String afficherUn(@PathVariable int id, Model model) {
        try {
            Evenement evenement = gestion.trouverParId(id);
            EvenementDTO evenementDTO = new EvenementDTO();
            evenementDTO.setNom(evenement.getNom());
            evenementDTO.setLieu(evenement.getLieu());
            evenementDTO.setDate(evenement.getDate());
            model.addAttribute("evenement", evenementDTO);
            model.addAttribute("id", id);
            return "detail";
        } catch (EvenementInconnuException e) {
            model.addAttribute("erreur", "Événement introuvable.");
            return "erreur";
        }
    }

    @GetMapping("/evenements")
    public String lister(Model model) {
        model.addAttribute("evenements", gestion.lister());
        return "liste";
    }
}
