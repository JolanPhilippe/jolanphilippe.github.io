package fr.info.orleans.pnt.springmvc.tpspringmvcevenements;

import fr.info.orleans.pnt.springmvc.tpspringmvcevenements.dto.EvenementDTO;

public class Evenement {

    private final int identifiant;
    private String nom;
    private String lieu;
    private String date;

    static public Evenement fromDTO(EvenementDTO dto, int id) {
        return new Evenement(id, dto.getNom(), dto.getLieu(), dto.getDate());
    }

    public Evenement(int identifiant, String nom, String lieu, String date) {
        this.identifiant = identifiant;
        this.nom = nom;
        this.lieu = lieu;
        this.date = date;
    }

    // getters et setters
    public int getIdentifiant() { return identifiant; }
    public String getNom() { return nom; }
    public String getLieu() { return lieu; }
    public String getDate() { return date; }

    public void setDate(String date) { this.date = date; }
    public void setLieu(String lieu) { this.lieu = lieu; }
    public void setNom(String nom) { this.nom = nom; }

}


