package fr.info.orleans.pnt.springmvc.tpspringmvcevenements.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class EvenementDTO {

 // private final int identifiant;

    @NotBlank()
    @Size(max = 50)
    private String nom;

    @NotBlank()
    @Size(max = 50, message = "Le lieu ne doit pas dépasser 50 caractères.")
    private String lieu;

    @NotBlank()
    private String date;

    public EvenementDTO(){}

    public EvenementDTO( String nom, String lieu, String date) {
     // this.identifiant = identifiant;
        this.nom = nom;
        this.lieu = lieu;
        this.date = date;
    }

    // Getters et Setters
    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }

    public String getLieu() { return lieu; }
    public void setLieu(String lieu) { this.lieu = lieu; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

}