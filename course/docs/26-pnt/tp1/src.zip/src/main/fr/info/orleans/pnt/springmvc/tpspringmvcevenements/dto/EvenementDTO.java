package fr.info.orleans.pnt.springmvc.tpspringmvcevenements.dto;

import fr.info.orleans.pnt.springmvc.tpspringmvcevenements.Evenement;

public class EvenementDTO {

 // private final int identifiant;
    private String nom;
    private String lieu;
    private String date;

    public EvenementDTO(){}

    public EvenementDTO( String nom, String lieu, String date) {
     // this.identifiant = identifiant;
        this.nom = nom;
        this.lieu = lieu;
        this.date = date;
    }

    // Getters et Setters
    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }

    public String getLieu() { return lieu; }
    public void setLieu(String lieu) { this.lieu = lieu; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

}