package fr.info.orleans.pnt.springmvc.tpspringmvcevenements.controleur;

import fr.info.orleans.pnt.springmvc.tpspringmvcevenements.Evenement;
import fr.info.orleans.pnt.springmvc.tpspringmvcevenements.dto.EvenementDTO;
import fr.info.orleans.pnt.springmvc.tpspringmvcevenements.modele.EvenementInconnuException;
import fr.info.orleans.pnt.springmvc.tpspringmvcevenements.modele.GestionEvenements;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;

/* Spring va scanner les classes, et instancier automatiquement
les classes @Controller; @Service; etc. */
@Controller
@RequestMapping("/mesevenements")
public class EvenementControleur {

    private final GestionEvenements gestion;

    public EvenementControleur(GestionEvenements gestion) {
        this.gestion = gestion;
    }

    @GetMapping("/ajouter")
    public String ajouter(
            /* @RequestParam sert à récupérer les arguments passés dans la requete (ie l'url)
            * Exemple:
            * http://localhost:8080/mesevenements/ajouter?nom=Festival&lieu=Marseille&date=2025-08-01
            * nom, lieu, et date vont être récupéré
            * */
            @RequestParam String nom,
            @RequestParam String lieu,
            @RequestParam String date,
            /* L'objet Model sert à passer des objets depuis le controleur à la vue
            * Ici la vue est un template, géré par Tymeleaf
            * (autrement on ne pourrait pas passer d'arg dans un fichier html)
            * */
            Model model
    ) {
//        int identifiant = gestion.enregistrer(nom, lieu, date);
        EvenementDTO e = new EvenementDTO();
        e.setNom(nom);
        e.setLieu(lieu);
        e.setDate(date);
        int identifiant = gestion.enregistrer(e);

        /* On set des valeurs pour des attributes à notre model. Le model sera utilisé pour la vue */
        model.addAttribute("message", "Événement ajouté avec succès !");
        model.addAttribute("identifiant", identifiant);
        /* Retourne le nom de la vue */
//        return "resume";
//        return "redirect:/mesevenements/evenements";
        return "forward:/mesevenements/evenements";
    }


    @GetMapping("/ajouter2")
    public String ajouterViaModel(
            /* @ModelAttribute encapsule les @RequestParam de `ajouter`
            * Du coup, l'objet créé est rempli automatiquement avec les champs de la requête
            * Exemple:
            * http://localhost:8080/mesevenements/ajouter2?nom=Festival&lieu=Marseille&date=2025-08-01
            *  */
            @ModelAttribute EvenementDTO evenement,
            Model model
    ){
        int identifiant = gestion.enregistrer(evenement);
        model.addAttribute("message", "Événement ajouté avec succès !");
        model.addAttribute("identifiant", identifiant);
        return "resume";
    }


    @GetMapping("/evenement/{id}")
    public String afficherUn(@PathVariable int id, Model model) {
        try {
            Evenement evenement = gestion.trouverParId(id);
            EvenementDTO evenementDTO = new EvenementDTO();
            evenementDTO.setNom(evenement.getNom());
            evenementDTO.setLieu(evenement.getLieu());
            evenementDTO.setDate(evenement.getDate());
            model.addAttribute("evenement", evenementDTO);
            model.addAttribute("id", id);
            return "detail";
        } catch (EvenementInconnuException e) {
            model.addAttribute("erreur", "Événement introuvable.");
            return "erreur";
        }
    }

    @GetMapping("/evenements")
    public String lister(Model model) {
        model.addAttribute("evenements", gestion.lister());
        return "liste";
    }
}
