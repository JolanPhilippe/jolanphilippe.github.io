package fr.info.orleans.pnt.springmvc.tpspringmvcevenements.modele;

public class EvenementInconnuException extends Exception {
    public EvenementInconnuException(String s) {
        super(s);
    }
}
