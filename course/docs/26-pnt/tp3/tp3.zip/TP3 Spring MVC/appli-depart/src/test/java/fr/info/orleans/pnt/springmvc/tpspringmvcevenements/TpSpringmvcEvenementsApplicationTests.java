package fr.info.orleans.pnt.springmvc.tpspringmvcevenements;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpSpringmvcEvenementsApplicationTests {

	@Test
	void contextLoads() {
	}

}
