# Demo provisionnement de fichier avec Terraform

## Initialiser le repertoire de travail Terraform

Depuis le dossier contenant le `main.tf` :

```bash
terraform init
```

Cette commande télécharge les providers nécéssaires pour provisionner les ressources déclarées dans `main.tf`.

## Formatter et valider son fichier 

Executer les commandes suivantes permet de formatter syntaxiquement le fichier terraform courant et ensuite de la valider (vérification des types, des attributs obligatoires, des références, des checks, etc).

```bash
terraform fmt
terraform validate
```

## Planifier la reconciliation

```bash
terraform plan
```

Cette commande affiche le plan d'éxécution nécéssaire pour atteindre l'infrastructure cible.
Il est possible de stocker le plan dans un fichier avec:

```bash
terraform plan -out=tfplan
terraform show tfplan
```

Le graphe de dépendance associé est alors disponible avec 

```bash
terraform graph > graph.dot
dot =Tsvg graph.dot > graph.svg
```


## Appliquer le plan

La commande 
```bash
terraform apply
```
créé un plan et l'applique par la suite. Il est toutefois possible d'appliquer un plan préalablement construit avec:
```bash
terraform plan -out=tfplan
terraform apply tfplan
```

L'état de l'infrastructure est alors stocké dans un fichier `terraform.tfstate`

## Supprimer son infrastructure

```bash
terraform destroy
```

Cette commande supprime entierement l'infrastructure, et supprime aussi les providers téléchargés localement
