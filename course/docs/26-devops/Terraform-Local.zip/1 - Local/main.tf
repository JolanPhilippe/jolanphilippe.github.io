terraform {
  required_version = ">= 1.6.0"
  required_providers {
    local = {
      source  = "hashicorp/local"
      version = "~> 2.9"
    }
  }
}

provider "local" {}

# var environment: string := "demo"
variable "environment" {
  type    = string
  default = "demo"
}

# constantes locales
locals {
  output_dir = "${path.module}/generated"
  app_name   = "terraform-${var.environment}"
}

# ressources 
resource "local_file" "database" {
  filename="${local.output_dir}/database.conf"
  content= <<-EOT
    host=localhost
    port=5432
    database=${local.app_name}
  EOT
}

resource "local_file" "application" {
  filename="${local.output_dir}/application.conf"
  content=<<-EOT
    app_name=${local.app_name}
    database_config=${local_file.database.filename}
  EOT
}

resource "local_file" "manifest" {
  filename="${local.output_dir}/manifest.txt"
  content="Infrastructure locale ${local.app_name} prête. \n"
  depends_on = [ 
    local_file.application
   ]
}

# outputs
output "generated_files" {
  value=[
    local_file.database.filename,
    local_file.application.filename,
    local_file.manifest.filename
  ]
}

output "application_sha256" {
  value = local_file.application.content_sha256
}

output "manifest_id" {
  value = local_file.manifest.id
}  
