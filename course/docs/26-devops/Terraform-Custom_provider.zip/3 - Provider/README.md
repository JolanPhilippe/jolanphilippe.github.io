# Provider Terraform

Petit provider Terraform minimaliste pour comprendre la structure d'un provider.
Il ne réalise pas d'action particulière, à part afficher un message lors de l'utilisation de la ressource. 

## Structure

```text
Provider/
├── go.mod
├── main.go
├── provider.go
└── resource_simple/
    └── simple.go
```

### `go.mod`

Décrit le module Go du projet et ses dépendances.
Il contient notamment les dépendances nécessaires au développement du provider Terraform.

### `main.go`

Point d'entrée du programme.
Il démarre le provider et permet à Terraform de communiquer avec celui-ci.

### `provider.go`

Déclare et configure le provider Terraform.
Il indique notamment quelles ressources sont disponibles dans le provider.

### `resource_simple/simple.go`

Implémente la ressource Terraform `simple`.
Ce fichier contient les fonctions associées au cycle de vie de la ressource (`Create`, `Read`, `Update`, `Delete`).
Dans cet exemple, la ressource ne fait rien de particulier et sert principalement à afficher un message.
