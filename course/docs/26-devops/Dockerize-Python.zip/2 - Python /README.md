# Demo Python avec Docker

## Construire l'image

Depuis le dossier contenant le `Dockerfile` :

```bash
docker build -t demo-python .
```

Cette commande construit une image Docker nommée `demo-python`.

## Démarrer le conteneur

```bash
docker run --name demo -p 8080:8000 demo-python
```

Cette commande :

* crée un conteneur nommé `demo`
* utilise l'image `demo-python`
* redirige le port `8080` de la machine hôte vers le port `8000` du conteneur

Le service est ensuite accessible à l'adresse :

```text
http://127.0.0.1:8080/docs
```

Le port `8000` correspond au port utilisé dans le conteneur. Depuis la machine hôte, on utilise le port `8080` grâce à la redirection `-p 8080:8000`.

## Arrêter et supprimer le conteneur

```bash
docker rm -f demo
```

L'option `-f` force l'arrêt du conteneur avant sa suppression.

## Supprimer l'image Docker

```bash
docker rmi demo-python
```

Cette commande supprime l'image `demo-python`.
