import os
from datetime import datetime

# enregistrer des mesures avec un nom et une valeur, par exemple temperature = 21.5
# stocker ces mesures dans une base SQLite avec SQLAlchemy
# relire toutes les mesures
# calculer des statistiques avec Pandas et NumPy : moyenne, médiane, minimum, maximum, écart-type
# exposer tout ça via une API FastAPI
# générer automatiquement une documentation Swagger sur /docs
# afficher une petite page HTML avec Jinja2
# faire un appel HTTP externe avec HTTPX via /external
# afficher des logs colorés avec Rich

import httpx
import numpy as np
import pandas as pd
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from jinja2 import Template
from pydantic import BaseModel
from rich.console import Console
from sqlalchemy import Column, DateTime, Float, Integer, String, create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

load_dotenv()

APP_NAME = os.getenv("APP_NAME", "Super Python Demo")
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./demo.db")

console = Console()

app = FastAPI(
    title=APP_NAME,
    version="1.0.0",
)

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False}
    if DATABASE_URL.startswith("sqlite")
    else {},
)

SessionLocal = sessionmaker(
    bind=engine,
    autoflush=False,
    autocommit=False,
)

Base = declarative_base()

class Measurement(Base):
    __tablename__ = "measurements"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    value = Column(Float, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

Base.metadata.create_all(bind=engine)

class MeasurementCreate(BaseModel):
    name: str
    value: float

@app.get("/")
def root():
    return {
        "message": f"Bienvenue dans {APP_NAME}",
        "docs": "/docs",
        "stats": "/stats",
        "measurements": "/measurements",
    }


@app.get("/health")
def health():
    return {
        "status": "ok",
        "timestamp": datetime.utcnow().isoformat(),
    }


@app.post("/measurements")
def create_measurement(measurement: MeasurementCreate):
    db = SessionLocal()

    try:
        row = Measurement(
            name=measurement.name,
            value=measurement.value,
        )

        db.add(row)
        db.commit()
        db.refresh(row)

        console.print(
            f"[green]Nouvelle mesure enregistrée : "
            f"{row.name} = {row.value}[/green]"
        )

        return {
            "id": row.id,
            "name": row.name,
            "value": row.value,
            "created_at": row.created_at,
        }

    finally:
        db.close()


@app.get("/measurements")
def get_measurements():
    db = SessionLocal()

    try:
        rows = db.query(Measurement).all()

        return [
            {
                "id": row.id,
                "name": row.name,
                "value": row.value,
                "created_at": row.created_at,
            }
            for row in rows
        ]

    finally:
        db.close()


@app.get("/stats")
def stats():
    db = SessionLocal()

    try:
        rows = db.query(Measurement).all()

        if not rows:
            raise HTTPException(
                status_code=404,
                detail="Aucune mesure enregistrée",
            )

        # Pandas
        df = pd.DataFrame(
            [
                {
                    "name": row.name,
                    "value": row.value,
                }
                for row in rows
            ]
        )

        # NumPy
        values = np.array(df["value"])

        return {
            "count": int(len(values)),
            "mean": float(np.mean(values)),
            "median": float(np.median(values)),
            "minimum": float(np.min(values)),
            "maximum": float(np.max(values)),
            "std": float(np.std(values)),
        }

    finally:
        db.close()


@app.get("/external")
async def external_api():
    """
    Exemple d'appel HTTP asynchrone avec HTTPX.
    """
    async with httpx.AsyncClient(timeout=10) as client:
        response = await client.get(
            "https://jsonplaceholder.typicode.com/todos/1"
        )

        response.raise_for_status()

        return response.json()


@app.get("  ", response_class=HTMLResponse)
def html_page():
    """
    Exemple d'utilisation de Jinja2 sans fichier template séparé.
    """

    template = Template(
        """
        <!DOCTYPE html>
        <html lang="fr">
        <head>
            <meta charset="UTF-8">
            <title>{{ app_name }}</title>
        </head>

        <body>
            <h1>{{ app_name }}</h1>

            <p>
                Cette page HTML est générée avec Jinja2.
            </p>

            <ul>
                <li><a href="/docs">Documentation Swagger</a></li>
                <li><a href="/measurements">Mesures</a></li>
                <li><a href="/stats">Statistiques</a></li>
                <li><a href="/health">Health check</a></li>
            </ul>
        </body>
        </html>
        """
    )

    return template.render(app_name=APP_NAME)