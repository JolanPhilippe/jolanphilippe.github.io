#!/bin/bash

virsh \
  -c "qemu:///session?socket=$HOME/.cache/libvirt/libvirt-sock" \
  list

# 127.0.0.1:2222
#        │
#        ▼
# QEMU user network
#        │
#        ▼
# 10.0.2.15:22

virsh \
  -c "qemu:///session?socket=$HOME/.cache/libvirt/libvirt-sock" \
  qemu-monitor-command \
  tf-ansible-demo \
  --hmp \
  'hostfwd_add tcp:127.0.0.1:2222-:22'

# Test port
nc -vz 127.0.0.1 2222

ssh-keygen -R "[127.0.0.1]:2222"
ssh \
  -p 2222 \
  -i ~/.ssh/id_ed25519 \
  -o StrictHostKeyChecking=no \
  -o UserKnownHostsFile=/dev/null \
  ansible@127.0.0.1