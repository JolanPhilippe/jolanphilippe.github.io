data "libvirt_domain_interface_addresses" "vm" {
  domain = libvirt_domain.vm.name
  source = "agent"

  depends_on = [
    libvirt_domain.vm
  ]
}

locals {
  vm_ipv4s = flatten([
    for iface in data.libvirt_domain_interface_addresses.vm.interfaces : [
      for addr in iface.addrs : addr.addr
      if addr.type == "ipv4" && !startswith(addr.addr, "127.")
    ]
  ])
}

output "vm_name" {
  description = "Nom de la VM"
  value       = libvirt_domain.vm.name
}

output "vm_uuid" {
  description = "UUID de la VM"
  value       = libvirt_domain.vm.uuid
}

output "vm_ip" {
  description = "Adresse IPv4 de la VM"
  value       = try(local.vm_ipv4s[0], null)
}