terraform {
  required_version = ">= 1.10"

  required_providers {
    libvirt = {
      source  = "dmacvicar/libvirt"
      version = "0.9.7"
    }
  }
}

# Libvirt
provider "libvirt" {
  # macOS
  uri = "qemu:///session?socket=/Users/jolan/.cache/libvirt/libvirt-sock"
}

# Image Ubuntu 24.04 ARM64
resource "libvirt_volume" "ubuntu_base" {
  name = "ubuntu-24.04-base.qcow2"
  pool = "default"
  target = {
    format = {
      type = "qcow2"
    }
  }
  create = {
    content = {
      url = "https://cloud-images.ubuntu.com/releases/server/24.04/release/ubuntu-24.04-server-cloudimg-arm64.img"
    }
  }
}

# Disque principal de la VM
resource "libvirt_volume" "vm_disk" {
  name = "tf-ansible-demo.qcow2"
  pool = "default"
  capacity      = 20
  capacity_unit = "GiB"
  target = {
    format = {
      type = "qcow2"
    }
  }
  backing_store = {
    path = libvirt_volume.ubuntu_base.path

    format = {
      type = "qcow2"
    }
  }
}

# Cloud-init
resource "libvirt_cloudinit_disk" "cloudinit" {
  name = "tf-ansible-demo-cloudinit"

  meta_data = yamlencode({
    instance-id    = "tf-ansible-demo"
    local-hostname = "tf-ansible-demo"
  })
  user_data = templatefile(
    "${path.module}/cloud-init.yaml.tftpl",
    {
      ssh_public_key = trimspace(
        file(pathexpand(var.ssh_public_key_path))
      )
    }
  )
}

# ISO cloud-init
resource "libvirt_volume" "cloudinit_iso" {
  name = "tf-ansible-demo-cloudinit.iso"
  pool = "default"

  target = {
    format = {
      type = "iso"
    }
  }

  create = {
    content = {
      url = libvirt_cloudinit_disk.cloudinit.path
    }
  }
}

# VM
resource "libvirt_domain" "vm" {
  name = "tf-ansible-demo"
  memory      = 2048
  memory_unit = "MiB"
  vcpu        = 2
  # Apple Silicon / macOS
  type = "hvf"
  running   = true
  autostart = false
  # ARM64 + UEFI
  os = {
    type         = "hvm"
    type_arch    = "aarch64"
    type_machine = "virt"
    firmware     = "efi"
  }
  # CPU natif Apple Silicon
  cpu = {
    mode = "host-passthrough"
  }
  # HVF nécessite GICv3
  features = {
    gic = {
      version = "3"
    }
  }
  devices = {
    # Disques
    disks = [
      {
        device = "disk"

        driver = {
          name = "qemu"
          type = "qcow2"
        }
        source = {
          volume = {
            pool   = libvirt_volume.vm_disk.pool
            volume = libvirt_volume.vm_disk.name
          }
        }
        target = {
          dev = "vda"
          bus = "virtio"
        }
      },
      # Cloud-init
      {
        device   = "cdrom"
        readonly = true
        source = {
          volume = {
            pool   = libvirt_volume.cloudinit_iso.pool
            volume = libvirt_volume.cloudinit_iso.name
          }
        }
        target = {
          dev = "sda"
          bus = "sata"
        }
      }
    ]
    # Réseau QEMU user-mode
    interfaces = [
      {
        model = {
          type = "virtio"
        }
        source = {
          user = {}
        }
        # Wait ip from QEMU Guest Agent 
        wait_for_ip = {
          source  = "agent"
          timeout = 300
        }
      }
    ]
    # QEMU Guest Agent
    channels = [
      {
        source = {
          unix = {
            mode = "bind"
          }
        }
        target = {
          type = "virtio"
          virt_io = {
            name = "org.qemu.guest_agent.0"
          }
        }
      }
    ]
    # Console série
    consoles = [
      {
        type = "pty"
        target = {
          type = "serial"
        }
      }
    ]
  }
}