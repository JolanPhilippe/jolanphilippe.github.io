variable "ssh_public_key_path" {
  description = "SSH public key injected into the VM"
  type        = string
  default     = "~/.ssh/id_ed25519.pub"
}