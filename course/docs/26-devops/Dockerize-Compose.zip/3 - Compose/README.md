# Déploiement avec Docker Compose

## Lancer les conteneurs

```bash
docker compose up --build
```

L'option `--build` force la reconstruction des images avant de démarrer les conteneurs.

## Backend

Le backend démarre sur le port `5000`.

Exemple de logs :

```text
backend-1  | * Running on http://127.0.0.1:5000
backend-1  | * Running on http://172.18.0.2:5000
```

L'adresse `172.18.0.2` correspond à l'adresse du conteneur sur le réseau Docker.

## Frontend

Le frontend est accessible depuis la machine hôte sur :

```text
http://localhost:3000
```

## Arrêter les conteneurs

Pour arrêter et supprimer les conteneurs créés par Docker Compose :

```bash
docker compose down
```

Les images resetent cependant. Pour les supprimer, il faut utiliser

```bash
docker rmi [id]
```