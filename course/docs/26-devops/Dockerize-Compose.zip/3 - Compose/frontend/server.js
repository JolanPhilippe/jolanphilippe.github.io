import express from "express";

const app = express();

const PORT = 3000;
const BACKEND_URL =
  process.env.BACKEND_URL || "http://localhost:5000";

app.get("/", async (req, res) => {
  try {
    const response = await fetch(`${BACKEND_URL}/api/hello`);
    const data = await response.json();

    res.send(`
      <h1>Frontend Node.js</h1>
      <p>Réponse du backend : ${data.message}</p>
    `);
  } catch (error) {
    res.status(500).send(
      `Impossible de contacter le backend : ${error.message}`
    );
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Frontend démarré sur le port ${PORT}`);
});