# Provisionner une VM avec Terraform et la configurer avec Ansible

## Terraform

Dans un premier temps, il s'agit d'instancier une VM surlaquelle on installera plus tard Docker pour y démarrer un conteneur.

Dans le dossier `terraform`, lancez les commandes
```
terraform init
terraform apply
```

Note: la ressource décrite ici est une VM proposée par le provider `libvirt`. Cependant, par problème de compatibilité, l'image de la VM est disponible à l'adresse: https://cloud-images.ubuntu.com/releases/server/24.04/release/ubuntu-24.04-server-cloudimg-arm64.img 
Il est possible que cette image ne soit pas compatible avec tous les OS. Il faut donc adapter l'image dans ce cas. 

## Ansible

Une fois la VM installée, il faut dans un premier temps en permettre l'accès. Dans le dossier `ansible`, le script `test_vm.sh` configure la redirection d'IP pour permettre d'éxécuter des commandes via ssh dans la VM.
Il faut executer ce script avant d'essayer d'executer le script Ansible.

Pour executer le script Ansible:
```
ansible-playbook docker.yml -i inventory.ini
```