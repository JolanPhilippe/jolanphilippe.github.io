package fr.miage.orleans.wsi.serveur.service;



import fr.miage.orleans.wsi.serveur.modele.*;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import static fr.miage.orleans.wsi.serveur.modele.ReservationStatusModel.STATUS_CONFIRMED;

public class FacadeCarRentalImpl implements IFacadeCarRental{

    private static final long SECONDS_PER_DAY = 86_400L;

    private final Map<String, Car> cars;
    private final Map<String, Reservation> reservations;

    public FacadeCarRentalImpl() {
        cars = new ConcurrentHashMap<>();
        reservations = new ConcurrentHashMap<>();
    }

    @Override
    public void addCar(String id, String brand, String model, String city,
                       CarCategoryModel category, long pricePerDayCents,
                       String... equipment) {
        Car car = Car.newBuilder()
                .setId(id)
                .setBrand(brand)
                .setModel(model)
                .setCity(city)
                .setCategory(category)
                .setPricePerDayCents(pricePerDayCents)
                .addAllEquipment(Arrays.asList(equipment))
                .build();
        cars.put(id, car);
    }

    @Override
    public Car getCar(String carId) {
        Car car = cars.getOrDefault(carId, null);
        if (car == null) {
            throw new NoSuchElementException("Voiture introuvable : " + carId);
        }
        return car;
    }

    private static void validatePeriod(Long start, Long end) {
        if (start == null || end == null || start < 0 || end <= start) {
            throw new IllegalArgumentException(
                    "Période invalide : end doit être > start >= 0");
        }
    }

    private boolean isAvailable(String carId, Long start, Long end) {
        /* Verifie s'il existe déjà une reservation confirmée pour cette voiture
        entre ces deux dates */
        return reservations.values().stream().noneMatch(reservation ->
                reservation.getCarId().equals(carId)
                        && reservation.getStatus() == STATUS_CONFIRMED
                        && start < reservation.getEndEpochSeconds()
                        && reservation.getStartEpochSeconds() < end);
    }

    @Override
    public Reservation createReservation(String carId, String customerId,
                                         Long start, Long end) {
        validatePeriod(start, end);
        Car car = getCar(carId);
        if (!isAvailable(carId, start, end)) {
            throw new IllegalStateException(
                    "Voiture indisponible pour la période demandée : " + carId);
        }

        long numberOfDays = ((end - start) - 1) / SECONDS_PER_DAY + 1;
        long totalPriceCents = numberOfDays * car.getPricePerDayCents();

        Reservation reservation = Reservation.newBuilder()
                .setId(UUID.randomUUID().toString())
                .setCarId(carId)
                .setCustomerId(customerId)
                .setStartEpochSeconds(start.longValue())
                .setEndEpochSeconds(end.longValue())
                .setTotalPriceCents(totalPriceCents)
                .setStatus(STATUS_CONFIRMED)
                .build();

        reservations.put(reservation.getId(), reservation);
        return reservation;
    }

    @Override
    public Reservation getReservation(String reservationId) {
        Reservation reservation = reservations.getOrDefault(reservationId, null);
        if (reservation == null) {
            throw new NoSuchElementException("Réservation introuvable : " + reservationId);
        }
        return reservation;
    }

    @Override
    public boolean cancelReservation(String reservationId) {
        Reservation reservation = getReservation(reservationId);
        if (reservation.getStatus() == ReservationStatusModel.STATUS_CANCELLED) {
            return false;
        }
        reservations.put(reservationId, reservation.toBuilder()
                .setStatus(ReservationStatusModel.STATUS_CANCELLED)
                .build());
        return true;
    }

    @Override
    public List<Car> searchAvailableCars(Optional<String> city,
                                         Optional<Long> start,
                                         Optional<Long> end,
                                         Optional<CarCategoryModel> carCategory) {
        if (start.isPresent() != end.isPresent()) {
            throw new IllegalArgumentException("start et end doivent être fournis ensemble");
        }
        start.ifPresent(integer -> validatePeriod(integer, end.get()));

        return cars.values().stream()
                .filter(car -> city.isEmpty() || city.get().isBlank()
                        || car.getCity().equalsIgnoreCase(city.get().trim()))
                .filter(car -> carCategory.isEmpty()
                        || carCategory.get() == CarCategoryModel.CATEGORY_UNSPECIFIED
                        || car.getCategory() == carCategory.get())
                .filter(car -> start.isEmpty() || isAvailable(car.getId(),
                        start.get(), end.get()))
                .sorted((a, b) -> a.getId().compareTo(b.getId()))
                .toList();
    }

    @Override
    public InspectionSummary submitInspection(List<InspectionObservation> observations) {
        if (observations == null || observations.isEmpty()) {
            throw new IllegalArgumentException(
                    "L'état des lieux doit contenir au moins une observation");
        }
        if (observations.get(0) == null) {
            throw new IllegalArgumentException("Observation nulle");
        }

        String reservationId = observations.get(0).getReservationId();
        getReservation(reservationId); // Vérifie que la réservation existe.

        int damages = 0;
        for (InspectionObservation observation : observations) {
            if (observation == null) {
                throw new IllegalArgumentException("Observation nulle");
            }
            if (!reservationId.equals(observation.getReservationId())) {
                throw new IllegalArgumentException(
                        "Toutes les observations doivent concerner la même réservation");
            }

            DamageSeverityModel severity = observation.getSeverity();
            if (severity == DamageSeverityModel.SEVERITY_MINOR
                    || severity == DamageSeverityModel.SEVERITY_MAJOR) {
                damages++;
            }
        }

        return InspectionSummary.newBuilder()
                .setReservationId(reservationId)
                .setObservationsReceived(observations.size())
                .setDamagesDetected(damages)
                .build();
    }

}
