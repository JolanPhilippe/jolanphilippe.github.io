package fr.miage.orleans.wsi.serveur.service;

import fr.miage.orleans.wsi.serveur.modele.*;
import fr.miage.orleans.wsi.serveur.modele.CarCategoryModel;

import java.util.List;
import java.util.Optional;

public interface IFacadeCarRental {
    void addCar(String id, String brand, String model, String city,
                CarCategoryModel category, long pricePerDayCents,
                String... equipment);
    Car getCar(String carId);
    Reservation createReservation(String carId, String customerId, Long start, Long end);
    Reservation getReservation(String reservationId);
    boolean cancelReservation(String reservationId);
    List<Car> searchAvailableCars(Optional<String> city, Optional<Long> start,
                                  Optional<Long> end, Optional<CarCategoryModel> carCategory);
    InspectionSummary submitInspection(List<InspectionObservation> observations);
}
