package fr.miage.orleans.wsi.serveur.modele;

public enum ReservationStatusModel {
    STATUS_UNSPECIFIED,
    STATUS_CONFIRMED,
    STATUS_CANCELLED
}
