package fr.miage.orleans.wsi.serveur.modele;


public class Reservation {
    private final String id;
    private final String carId;
    private final String customerId;
    private final long startEpochSeconds;
    private final long endEpochSeconds;
    private final long totalPriceCents;
    private final ReservationStatusModel status;

    private Reservation(Builder builder) {
        this.id = builder.id;
        this.carId = builder.carId;
        this.customerId = builder.customerId;
        this.startEpochSeconds = builder.startEpochSeconds;
        this.endEpochSeconds = builder.endEpochSeconds;
        this.totalPriceCents = builder.totalPriceCents;
        this.status = builder.status;
    }

    // Getters
    public String getId() { return id; }
    public String getCarId() { return carId; }
    public String getCustomerId() { return customerId; }
    public long getStartEpochSeconds() { return startEpochSeconds; }
    public long getEndEpochSeconds() { return endEpochSeconds; }
    public long getTotalPriceCents() { return totalPriceCents; }
    public ReservationStatusModel getStatus() { return status; }

    public static Builder newBuilder() {
        return new Builder();
    }

    // Permet de repartir de l'instance existante
    public Builder toBuilder() {
        return new Builder(this);
    }

    public static class Builder {
        private String id;
        private String carId;
        private String customerId;
        private long startEpochSeconds;
        private long endEpochSeconds;
        private long totalPriceCents;
        private ReservationStatusModel status;

        public Builder() {}

        // Constructeur de copie pour toBuilder()
        private Builder(Reservation reservation) {
            this.id = reservation.id;
            this.carId = reservation.carId;
            this.customerId = reservation.customerId;
            this.startEpochSeconds = reservation.startEpochSeconds;
            this.endEpochSeconds = reservation.endEpochSeconds;
            this.totalPriceCents = reservation.totalPriceCents;
            this.status = reservation.status;
        }

        public Builder setId(String id) {
            this.id = id;
            return this;
        }

        public Builder setCarId(String carId) {
            this.carId = carId;
            return this;
        }

        public Builder setCustomerId(String customerId) {
            this.customerId = customerId;
            return this;
        }

        public Builder setStartEpochSeconds(long startEpochSeconds) {
            this.startEpochSeconds = startEpochSeconds;
            return this;
        }

        public Builder setEndEpochSeconds(long endEpochSeconds) {
            this.endEpochSeconds = endEpochSeconds;
            return this;
        }

        public Builder setTotalPriceCents(long totalPriceCents) {
            this.totalPriceCents = totalPriceCents;
            return this;
        }

        public Builder setStatus(ReservationStatusModel status) {
            this.status = status;
            return this;
        }

        public Reservation build() {
            return new Reservation(this);
        }
    }
}