package fr.miage.orleans.wsi.serveur.modele;

public enum CarCategoryModel {
    CATEGORY_UNSPECIFIED,
    CATEGORY_ECONOMY,
    CATEGORY_SUV,
    CATEGORY_PREMIUM
}
