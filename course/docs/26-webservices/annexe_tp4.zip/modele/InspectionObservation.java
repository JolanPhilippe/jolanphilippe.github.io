package fr.miage.orleans.wsi.serveur.modele;



public class InspectionObservation {
    private final String reservationId;
    private final String zone;
    private final String remarks;
    private final DamageSeverityModel severity;

    private InspectionObservation(Builder builder) {
        this.reservationId = builder.reservationId;
        this.zone = builder.zone;
        this.remarks = builder.remarks;
        this.severity = builder.severity;
    }

    public String getReservationId() { return reservationId; }
    public String getZone() { return zone; }
    public String getRemarks() { return remarks; }
    public DamageSeverityModel getSeverity() { return severity; }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Builder toBuilder() {
        return new Builder(this);
    }

    public static class Builder {
        private String reservationId;
        private String zone;
        private String remarks;
        private DamageSeverityModel severity;

        public Builder() {}

        private Builder(InspectionObservation observation) {
            this.reservationId = observation.reservationId;
            this.zone = observation.zone;
            this.remarks = observation.remarks;
            this.severity = observation.severity;
        }

        public Builder setReservationId(String reservationId) {
            this.reservationId = reservationId;
            return this;
        }

        public Builder setZone(String zone) {
            this.zone = zone;
            return this;
        }

        public Builder setRemarks(String remarks) {
            this.remarks = remarks;
            return this;
        }

        public Builder setSeverity(DamageSeverityModel severity) {
            this.severity = severity;
            return this;
        }

        public InspectionObservation build() {
            return new InspectionObservation(this);
        }
    }
}