package fr.miage.orleans.wsi.serveur.modele;


import java.util.ArrayList;
import java.util.List;

public class Car {
    private final String id;
    private final String brand;
    private final String model;
    private final String city;
    private final CarCategoryModel category;
    private final Long pricePerDayCents;
    private final List<String> equipment;

    private Car(Builder builder) {
        this.id = builder.id;
        this.brand = builder.brand;
        this.model = builder.model;
        this.city = builder.city;
        this.category = builder.category;
        this.pricePerDayCents = builder.pricePerDayCents;
        this.equipment = new ArrayList<>(builder.equipment);
    }

    // Getters
    public String getId() { return id; }
    public String getBrand() { return brand; }
    public String getModel() { return model; }
    public String getCity() { return city; }
    public CarCategoryModel getCategory() { return category; }
    public Long getPricePerDayCents() { return pricePerDayCents; }
    public List<String> getEquipment() { return equipment; }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static class Builder {
        private String id;
        private String brand;
        private String model;
        private String city;
        private CarCategoryModel category;
        private Long pricePerDayCents;
        private List<String> equipment = new ArrayList<>();

        public Builder setId(String id) {
            this.id = id;
            return this;
        }

        public Builder setBrand(String brand) {
            this.brand = brand;
            return this;
        }

        public Builder setModel(String model) {
            this.model = model;
            return this;
        }

        public Builder setCity(String city) {
            this.city = city;
            return this;
        }

        public Builder setCategory(CarCategoryModel category) {
            this.category = category;
            return this;
        }

        public Builder setPricePerDayCents(Long pricePerDayCents) {
            this.pricePerDayCents = pricePerDayCents;
            return this;
        }

        public Builder addAllEquipment(Iterable<String> equipment) {
            if (equipment != null) {
                equipment.forEach(this.equipment::add);
            }
            return this;
        }

        public Car build() {
            return new Car(this);
        }
    }
}