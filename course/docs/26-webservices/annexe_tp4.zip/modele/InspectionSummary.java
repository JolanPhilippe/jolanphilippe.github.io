package fr.miage.orleans.wsi.serveur.modele;

public class InspectionSummary {
    private final String reservationId;
    private final int observationsReceived;
    private final int damagesDetected;

    private InspectionSummary(Builder builder) {
        this.reservationId = builder.reservationId;
        this.observationsReceived = builder.observationsReceived;
        this.damagesDetected = builder.damagesDetected;
    }

    public String getReservationId() { return reservationId; }
    public int getObservationsReceived() { return observationsReceived; }
    public int getDamagesDetected() { return damagesDetected; }

    public static Builder newBuilder() {
        return new Builder();
    }

    public Builder toBuilder() {
        return new Builder(this);
    }

    public static class Builder {
        private String reservationId;
        private int observationsReceived;
        private int damagesDetected;

        public Builder() {}

        private Builder(InspectionSummary summary) {
            this.reservationId = summary.reservationId;
            this.observationsReceived = summary.observationsReceived;
            this.damagesDetected = summary.damagesDetected;
        }

        public Builder setReservationId(String reservationId) {
            this.reservationId = reservationId;
            return this;
        }

        public Builder setObservationsReceived(int observationsReceived) {
            this.observationsReceived = observationsReceived;
            return this;
        }

        public Builder setDamagesDetected(int damagesDetected) {
            this.damagesDetected = damagesDetected;
            return this;
        }

        public InspectionSummary build() {
            return new InspectionSummary(this);
        }
    }
}