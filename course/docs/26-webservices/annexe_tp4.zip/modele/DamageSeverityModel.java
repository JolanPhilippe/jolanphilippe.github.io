package fr.miage.orleans.wsi.serveur.modele;

public enum DamageSeverityModel {
    SEVERITY_UNSPECIFIED,
    SEVERITY_NONE,
    SEVERITY_MINOR,
    SEVERITY_MAJOR
}
